﻿using CapaDatos.Interface;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CapaNegocio.LN_Entidades
{
    /// <summary>
    /// Clase que representa la entidad ClienteVehiculo en la capa de negocio.
    /// </summary>
    public class CN_ClienteVehiculo
    {
        private Interface_Negocio objIntClienteVehiculo = new Interface_Negocio();
        private int id;
        private string nombre;
        private int edad;
        private string cedula;
        private int celular;
        private string correo;
        private string vehiculo;

        /// <summary>
        /// Constructor sin parámetros de la clase `CN_ClienteVehiculo`.
        /// </summary>
        public CN_ClienteVehiculo()
        {
            id = 0;
            nombre = string.Empty;
            edad = 0;
            cedula = string.Empty;
            celular = 0;
            correo = string.Empty;
            vehiculo = string.Empty;
        }

        /// <summary>
        /// Constructor con parámetros de la clase `CN_ClienteVehiculo`.
        /// </summary>
        public CN_ClienteVehiculo(int id, string nombre, int edad, string cedula, int celular, string correo, string vehiculo)
        {
            // Asignación de valores
            this.id = id;
            this.nombre = nombre;
            this.edad = edad;
            this.cedula = cedula;
            this.celular = celular;
            this.correo = correo;
            this.vehiculo = vehiculo;
        }   

        /// <summary>
        /// Propiedad para acceder el ID del cliente.
        /// </summary>
        public int Id
        {
            get { return id; }
            set { id = value; }
        }

        /// <summary>
        /// Propiedad para acceder el nombre del cliente.
        /// </summary>
        public string Nombre
        {
            get { return nombre; }
            set { nombre = value; }
        }

        /// <summary>
        /// Propiedad para acceder la edad del cliente.
        /// </summary>
        public int Edad
        {
            get { return edad; }
            set { edad = value; }
        }

        /// <summary>
        /// Propiedad para acceder al número de cédula del cliente.
        /// </summary>
        public string Cedula
        {
            get { return cedula; }
            set { cedula = value; }
        }

        /// <summary>
        /// Propiedad para acceder al número de celular del cliente.
        /// </summary>
        public int Celular
        {
            get { return celular; }
            set { celular = value; }
        }

        /// <summary>
        /// Propiedad para acceder al correo electrónico del cliente.
        /// </summary>
        public string Correo
        {
            get { return correo; }
            set { correo = value; }
        }

        /// <summary>
        /// Propiedad para acceder al vehículo asociado al cliente.
        /// </summary>
        public string Vehiculo
        {
            get { return vehiculo; }
            set { vehiculo = value; }
        }



        /// <summary>
        /// Obtiene un listado de clientes y vehículos desde la capa de datos.
        /// </summary>
        public DataTable getListadoClienteVehiculo()
        {
            try
            {
                return objIntClienteVehiculo.getListaClienteVehiculo();
            }
            catch (Exception e)
            {
                // Si ocurre una excepción, se lanza una nueva excepción con un mensaje descriptivo
                throw new Exception("Error al obtener listado de cliente y vehículo -> " + e.Message);
            }
        }

        /// <summary>
        /// Guarda un cliente y vehículo en la base de datos.
        /// </summary>
        public bool GuardarClienteVehiculo(CN_ClienteVehiculo clienteVehiculo)
        {
            try
            {
                // Se crea una lista de parámetros para enviar a la capa de datos
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@nombre", clienteVehiculo.Nombre, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@edad", clienteVehiculo.Edad, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@cedula", clienteVehiculo.Cedula, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@celular", clienteVehiculo.Celular, SqlDbType.BigInt));
                lista.Add(new CD_Parameter_SP("@correo", clienteVehiculo.Correo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@vehiculo", clienteVehiculo.Vehiculo, SqlDbType.Text));

                // Se llama al método de la capa de datos para guardar el cliente y vehículo
                return objIntClienteVehiculo.CreaClienteVehiculo(lista);
            }
            catch (Exception e)
            {
                // Si ocurre una excepción, se lanza una nueva excepción con un mensaje descriptivo
                throw new Exception("Error al Guardar Datos de Cliente y vehiculo -> " + e.Message);
            }
        }

        /// <summary>
        /// Actualiza un cliente y vehículo en la base de datos.
        /// </summary>
        public bool ActualizarClienteVehiculo(CN_ClienteVehiculo clienteVehiculo)
        {
            try
            {
                // Se crea una lista de parámetros para enviar a la capa de datos
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@id", clienteVehiculo.Id, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@nombre", clienteVehiculo.Nombre, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@edad", clienteVehiculo.Edad, SqlDbType.Int));
                lista.Add(new CD_Parameter_SP("@cedula", clienteVehiculo.Cedula, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@celular", clienteVehiculo.Celular, SqlDbType.BigInt));
                lista.Add(new CD_Parameter_SP("@correo", clienteVehiculo.Correo, SqlDbType.Text));
                lista.Add(new CD_Parameter_SP("@vehiculo", clienteVehiculo.Vehiculo, SqlDbType.Text));

                // Se llama al método de la capa de datos para actualizar el cliente y vehículo
                return objIntClienteVehiculo.ActualizarClienteVehiculo(lista);
            }
            catch (Exception e)
            {
                // Si ocurre una excepción, se lanza una nueva excepción con un mensaje descriptivo
                throw new Exception("Error al Actualizar Datos de Cliente y vehiculo -> " + e.Message);
            }
        }

        /// <summary>
        /// Elimina un cliente y vehículo de la base de datos.
        /// </summary>
        public bool EliminarClienteVehiculo(CN_ClienteVehiculo clienteVehiculo)
        {
            try
            {
                // Se crea una lista de parámetros para enviar a la capa de datos
                List<CD_Parameter_SP> lista = new List<CD_Parameter_SP>();
                lista.Add(new CD_Parameter_SP("@IdClienteVehiculo", clienteVehiculo.Id, SqlDbType.Int));

                // Se llama al método de la capa de datos para eliminar el cliente y vehículo
                return objIntClienteVehiculo.EliminaClienteVehiculo(lista);
            }
            catch (Exception e)
            {
                // Si ocurre una excepción, se lanza una nueva excepción con un mensaje descriptivo
                throw new Exception("Error al Eliminar Datos de Cliente y vehiculo -> " + e.Message);
            }
        }



    }
}
 
