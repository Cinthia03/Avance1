﻿namespace CapaPresentacion
{
    partial class frmMantenimiento
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMantenimiento));
            groupBox1 = new GroupBox();
            gbServiciosAdicionales = new GroupBox();
            txtTotalServAd = new TextBox();
            txtPrecioServicio = new TextBox();
            label7 = new Label();
            label8 = new Label();
            clbServiciosAdicionales = new CheckedListBox();
            cbVehiculo = new ComboBox();
            label3 = new Label();
            rtbRepuestos = new RichTextBox();
            btnCliente = new Button();
            txtNombre = new TextBox();
            label10 = new Label();
            label9 = new Label();
            txtTotal = new TextBox();
            txtSubtotal = new TextBox();
            txtTotalPreventivo = new TextBox();
            txtTotalCorrectivo = new TextBox();
            lbTotalTipoMant = new Label();
            gbTipoMantenimiento = new GroupBox();
            rbCorrectivo = new RadioButton();
            rbPreventivo = new RadioButton();
            rtbTrabajos = new RichTextBox();
            cmbMecanico = new ComboBox();
            txtId = new TextBox();
            label6 = new Label();
            label5 = new Label();
            dateTimePicker1 = new DateTimePicker();
            label4 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox4 = new GroupBox();
            btnServiciosAdicionales = new Button();
            rtbServicios = new RichTextBox();
            txtTotalServicios = new TextBox();
            lbTotalServicios = new Label();
            groupBox2 = new GroupBox();
            btnEliminar = new Button();
            btnNuevo = new Button();
            btnGrabar = new Button();
            dgvMantenimiento = new DataGridView();
            btnCalcular = new Button();
            groupBox1.SuspendLayout();
            gbServiciosAdicionales.SuspendLayout();
            gbTipoMantenimiento.SuspendLayout();
            groupBox4.SuspendLayout();
            groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvMantenimiento).BeginInit();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(gbServiciosAdicionales);
            groupBox1.Controls.Add(cbVehiculo);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(rtbRepuestos);
            groupBox1.Controls.Add(btnCliente);
            groupBox1.Controls.Add(txtNombre);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(txtTotal);
            groupBox1.Controls.Add(txtSubtotal);
            groupBox1.Controls.Add(txtTotalPreventivo);
            groupBox1.Controls.Add(txtTotalCorrectivo);
            groupBox1.Controls.Add(lbTotalTipoMant);
            groupBox1.Controls.Add(gbTipoMantenimiento);
            groupBox1.Controls.Add(rtbTrabajos);
            groupBox1.Controls.Add(cmbMecanico);
            groupBox1.Controls.Add(txtId);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(dateTimePicker1);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(label1);
            groupBox1.Location = new Point(12, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(814, 422);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "Datos del mantenimiento";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // gbServiciosAdicionales
            // 
            gbServiciosAdicionales.Controls.Add(txtTotalServAd);
            gbServiciosAdicionales.Controls.Add(txtPrecioServicio);
            gbServiciosAdicionales.Controls.Add(label7);
            gbServiciosAdicionales.Controls.Add(label8);
            gbServiciosAdicionales.Controls.Add(clbServiciosAdicionales);
            gbServiciosAdicionales.Location = new Point(29, 235);
            gbServiciosAdicionales.Name = "gbServiciosAdicionales";
            gbServiciosAdicionales.Size = new Size(455, 169);
            gbServiciosAdicionales.TabIndex = 34;
            gbServiciosAdicionales.TabStop = false;
            gbServiciosAdicionales.Text = "Servicios Adicionales";
            // 
            // txtTotalServAd
            // 
            txtTotalServAd.Location = new Point(346, 75);
            txtTotalServAd.Name = "txtTotalServAd";
            txtTotalServAd.ReadOnly = true;
            txtTotalServAd.Size = new Size(88, 23);
            txtTotalServAd.TabIndex = 22;
            // 
            // txtPrecioServicio
            // 
            txtPrecioServicio.Location = new Point(346, 33);
            txtPrecioServicio.Name = "txtPrecioServicio";
            txtPrecioServicio.ReadOnly = true;
            txtPrecioServicio.Size = new Size(88, 23);
            txtPrecioServicio.TabIndex = 45;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(224, 75);
            label7.Name = "label7";
            label7.Size = new Size(86, 15);
            label7.TabIndex = 21;
            label7.Text = "Total servicios: ";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(224, 36);
            label8.Name = "label8";
            label8.Size = new Size(116, 15);
            label8.TabIndex = 44;
            label8.Text = "Precio de c/servicio: ";
            // 
            // clbServiciosAdicionales
            // 
            clbServiciosAdicionales.FormattingEnabled = true;
            clbServiciosAdicionales.Location = new Point(35, 26);
            clbServiciosAdicionales.Name = "clbServiciosAdicionales";
            clbServiciosAdicionales.Size = new Size(177, 130);
            clbServiciosAdicionales.TabIndex = 23;
            // 
            // cbVehiculo
            // 
            cbVehiculo.FormattingEnabled = true;
            cbVehiculo.Location = new Point(479, 52);
            cbVehiculo.Name = "cbVehiculo";
            cbVehiculo.Size = new Size(245, 23);
            cbVehiculo.TabIndex = 14;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(405, 55);
            label3.Name = "label3";
            label3.Size = new Size(58, 15);
            label3.TabIndex = 13;
            label3.Text = "Vehiculo: ";
            // 
            // rtbRepuestos
            // 
            rtbRepuestos.Location = new Point(576, 138);
            rtbRepuestos.Name = "rtbRepuestos";
            rtbRepuestos.ReadOnly = true;
            rtbRepuestos.Size = new Size(133, 80);
            rtbRepuestos.TabIndex = 34;
            rtbRepuestos.Text = "";
            // 
            // btnCliente
            // 
            btnCliente.BackColor = SystemColors.Control;
            btnCliente.FlatStyle = FlatStyle.Popup;
            btnCliente.ForeColor = SystemColors.Control;
            btnCliente.Image = (Image)resources.GetObject("btnCliente.Image");
            btnCliente.Location = new Point(349, 53);
            btnCliente.Name = "btnCliente";
            btnCliente.Size = new Size(32, 24);
            btnCliente.TabIndex = 32;
            btnCliente.UseVisualStyleBackColor = false;
            btnCliente.Click += btnCliente_Click;
            // 
            // txtNombre
            // 
            txtNombre.Location = new Point(103, 53);
            txtNombre.Name = "txtNombre";
            txtNombre.ReadOnly = true;
            txtNombre.Size = new Size(236, 23);
            txtNombre.TabIndex = 31;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(643, 384);
            label10.Name = "label10";
            label10.Size = new Size(38, 15);
            label10.TabIndex = 24;
            label10.Text = "Total: ";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(643, 356);
            label9.Name = "label9";
            label9.Size = new Size(57, 15);
            label9.TabIndex = 23;
            label9.Text = "Subtotal: ";
            // 
            // txtTotal
            // 
            txtTotal.Location = new Point(715, 381);
            txtTotal.Name = "txtTotal";
            txtTotal.ReadOnly = true;
            txtTotal.Size = new Size(89, 23);
            txtTotal.TabIndex = 22;
            // 
            // txtSubtotal
            // 
            txtSubtotal.Location = new Point(716, 353);
            txtSubtotal.Name = "txtSubtotal";
            txtSubtotal.ReadOnly = true;
            txtSubtotal.Size = new Size(88, 23);
            txtSubtotal.TabIndex = 21;
            // 
            // txtTotalPreventivo
            // 
            txtTotalPreventivo.Location = new Point(576, 110);
            txtTotalPreventivo.Name = "txtTotalPreventivo";
            txtTotalPreventivo.ReadOnly = true;
            txtTotalPreventivo.Size = new Size(84, 23);
            txtTotalPreventivo.TabIndex = 20;
            // 
            // txtTotalCorrectivo
            // 
            txtTotalCorrectivo.Location = new Point(715, 138);
            txtTotalCorrectivo.Name = "txtTotalCorrectivo";
            txtTotalCorrectivo.ReadOnly = true;
            txtTotalCorrectivo.Size = new Size(93, 23);
            txtTotalCorrectivo.TabIndex = 16;
            // 
            // lbTotalTipoMant
            // 
            lbTotalTipoMant.AutoSize = true;
            lbTotalTipoMant.Location = new Point(603, 92);
            lbTotalTipoMant.Name = "lbTotalTipoMant";
            lbTotalTipoMant.Size = new Size(38, 15);
            lbTotalTipoMant.TabIndex = 15;
            lbTotalTipoMant.Text = "Total: ";
            // 
            // gbTipoMantenimiento
            // 
            gbTipoMantenimiento.Controls.Add(rbCorrectivo);
            gbTipoMantenimiento.Controls.Add(rbPreventivo);
            gbTipoMantenimiento.Location = new Point(411, 92);
            gbTipoMantenimiento.Name = "gbTipoMantenimiento";
            gbTipoMantenimiento.Size = new Size(149, 71);
            gbTipoMantenimiento.TabIndex = 14;
            gbTipoMantenimiento.TabStop = false;
            gbTipoMantenimiento.Text = "Tipo de mantenimiento";
            // 
            // rbCorrectivo
            // 
            rbCorrectivo.AutoSize = true;
            rbCorrectivo.Location = new Point(24, 47);
            rbCorrectivo.Name = "rbCorrectivo";
            rbCorrectivo.Size = new Size(80, 19);
            rbCorrectivo.TabIndex = 1;
            rbCorrectivo.TabStop = true;
            rbCorrectivo.Text = "Correctivo";
            rbCorrectivo.UseVisualStyleBackColor = true;
            rbCorrectivo.Click += rbCorrectivo_Click;
            // 
            // rbPreventivo
            // 
            rbPreventivo.AutoSize = true;
            rbPreventivo.Location = new Point(24, 22);
            rbPreventivo.Name = "rbPreventivo";
            rbPreventivo.Size = new Size(81, 19);
            rbPreventivo.TabIndex = 0;
            rbPreventivo.TabStop = true;
            rbPreventivo.Text = "Preventivo";
            rbPreventivo.UseVisualStyleBackColor = true;
            // 
            // rtbTrabajos
            // 
            rtbTrabajos.Location = new Point(29, 138);
            rtbTrabajos.Name = "rtbTrabajos";
            rtbTrabajos.Size = new Size(319, 80);
            rtbTrabajos.TabIndex = 13;
            rtbTrabajos.Text = "";
            // 
            // cmbMecanico
            // 
            cmbMecanico.FormattingEnabled = true;
            cmbMecanico.Location = new Point(103, 85);
            cmbMecanico.Name = "cmbMecanico";
            cmbMecanico.Size = new Size(236, 23);
            cmbMecanico.TabIndex = 12;
            // 
            // txtId
            // 
            txtId.Location = new Point(103, 22);
            txtId.Name = "txtId";
            txtId.ReadOnly = true;
            txtId.Size = new Size(41, 23);
            txtId.TabIndex = 7;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(29, 120);
            label6.Name = "label6";
            label6.Size = new Size(130, 15);
            label6.TabIndex = 6;
            label6.Text = "Trabajos y diagnostico: ";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(411, 30);
            label5.Name = "label5";
            label5.Size = new Size(44, 15);
            label5.TabIndex = 5;
            label5.Text = "Fecha: ";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(479, 24);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(216, 23);
            dateTimePicker1.TabIndex = 4;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(29, 88);
            label4.Name = "label4";
            label4.Size = new Size(65, 15);
            label4.TabIndex = 3;
            label4.Text = "Mecanico: ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(29, 56);
            label2.Name = "label2";
            label2.Size = new Size(50, 15);
            label2.TabIndex = 1;
            label2.Text = "Cliente: ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(29, 30);
            label1.Name = "label1";
            label1.Size = new Size(23, 15);
            label1.TabIndex = 0;
            label1.Text = "Id: ";
            // 
            // groupBox4
            // 
            groupBox4.Controls.Add(btnServiciosAdicionales);
            groupBox4.Controls.Add(rtbServicios);
            groupBox4.Controls.Add(txtTotalServicios);
            groupBox4.Controls.Add(lbTotalServicios);
            groupBox4.Location = new Point(959, 272);
            groupBox4.Name = "groupBox4";
            groupBox4.Size = new Size(328, 131);
            groupBox4.TabIndex = 33;
            groupBox4.TabStop = false;
            groupBox4.Text = "Servicios Adicionales";
            // 
            // btnServiciosAdicionales
            // 
            btnServiciosAdicionales.BackColor = SystemColors.Control;
            btnServiciosAdicionales.FlatStyle = FlatStyle.Popup;
            btnServiciosAdicionales.ForeColor = SystemColors.Control;
            btnServiciosAdicionales.Image = (Image)resources.GetObject("btnServiciosAdicionales.Image");
            btnServiciosAdicionales.Location = new Point(273, 22);
            btnServiciosAdicionales.Name = "btnServiciosAdicionales";
            btnServiciosAdicionales.Size = new Size(32, 24);
            btnServiciosAdicionales.TabIndex = 33;
            btnServiciosAdicionales.UseVisualStyleBackColor = false;
            btnServiciosAdicionales.Click += btnServiciosAdicionales_Click;
            // 
            // rtbServicios
            // 
            rtbServicios.Location = new Point(15, 22);
            rtbServicios.Name = "rtbServicios";
            rtbServicios.ReadOnly = true;
            rtbServicios.Size = new Size(241, 62);
            rtbServicios.TabIndex = 29;
            rtbServicios.Text = "";
            // 
            // txtTotalServicios
            // 
            txtTotalServicios.Location = new Point(171, 95);
            txtTotalServicios.Name = "txtTotalServicios";
            txtTotalServicios.ReadOnly = true;
            txtTotalServicios.Size = new Size(134, 23);
            txtTotalServicios.TabIndex = 19;
            // 
            // lbTotalServicios
            // 
            lbTotalServicios.AutoSize = true;
            lbTotalServicios.Location = new Point(76, 98);
            lbTotalServicios.Name = "lbTotalServicios";
            lbTotalServicios.Size = new Size(81, 15);
            lbTotalServicios.TabIndex = 18;
            lbTotalServicios.Text = "Total Servicios";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(btnEliminar);
            groupBox2.Controls.Add(btnNuevo);
            groupBox2.Controls.Add(btnGrabar);
            groupBox2.Location = new Point(832, 116);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(120, 139);
            groupBox2.TabIndex = 5;
            groupBox2.TabStop = false;
            // 
            // btnEliminar
            // 
            btnEliminar.Enabled = false;
            btnEliminar.Location = new Point(5, 102);
            btnEliminar.Margin = new Padding(2);
            btnEliminar.Name = "btnEliminar";
            btnEliminar.Size = new Size(105, 23);
            btnEliminar.TabIndex = 30;
            btnEliminar.Text = "Eliminar";
            btnEliminar.UseVisualStyleBackColor = true;
            btnEliminar.Click += btnEliminar_Click;
            // 
            // btnNuevo
            // 
            btnNuevo.Location = new Point(5, 21);
            btnNuevo.Margin = new Padding(2);
            btnNuevo.Name = "btnNuevo";
            btnNuevo.Size = new Size(105, 23);
            btnNuevo.TabIndex = 28;
            btnNuevo.Text = "Nuevo";
            btnNuevo.UseVisualStyleBackColor = true;
            btnNuevo.Click += btnNuevo_Click;
            // 
            // btnGrabar
            // 
            btnGrabar.Enabled = false;
            btnGrabar.Location = new Point(5, 62);
            btnGrabar.Margin = new Padding(2);
            btnGrabar.Name = "btnGrabar";
            btnGrabar.Size = new Size(105, 23);
            btnGrabar.TabIndex = 29;
            btnGrabar.Text = "Grabar";
            btnGrabar.UseVisualStyleBackColor = true;
            btnGrabar.Click += btnGrabar_Click;
            // 
            // dgvMantenimiento
            // 
            dgvMantenimiento.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMantenimiento.Location = new Point(12, 440);
            dgvMantenimiento.Name = "dgvMantenimiento";
            dgvMantenimiento.RowTemplate.Height = 25;
            dgvMantenimiento.Size = new Size(940, 169);
            dgvMantenimiento.TabIndex = 6;
            dgvMantenimiento.CellClick += dgvMantenimiento_CellClick;
            dgvMantenimiento.DoubleClick += dgvMantenimiento_DoubleClick;
            // 
            // btnCalcular
            // 
            btnCalcular.Location = new Point(849, 272);
            btnCalcular.Name = "btnCalcular";
            btnCalcular.Size = new Size(75, 23);
            btnCalcular.TabIndex = 7;
            btnCalcular.Text = "Calcular";
            btnCalcular.UseVisualStyleBackColor = true;
            btnCalcular.Click += btnCalcular_Click;
            // 
            // frmMantenimiento
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1299, 634);
            Controls.Add(btnCalcular);
            Controls.Add(dgvMantenimiento);
            Controls.Add(groupBox2);
            Controls.Add(groupBox4);
            Controls.Add(groupBox1);
            Name = "frmMantenimiento";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "frmMantenimiento";
            Load += frmMantenimiento_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            gbServiciosAdicionales.ResumeLayout(false);
            gbServiciosAdicionales.PerformLayout();
            gbTipoMantenimiento.ResumeLayout(false);
            gbTipoMantenimiento.PerformLayout();
            groupBox4.ResumeLayout(false);
            groupBox4.PerformLayout();
            groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvMantenimiento).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Label label2;
        private Label label1;
        private RichTextBox rtbTrabajos;
        private ComboBox cmbMecanico;
        private TextBox txtId;
        private Label label6;
        private Label label5;
        private DateTimePicker dateTimePicker1;
        private Label label4;
        private GroupBox groupBox2;
        private Button btnEliminar;
        private Button btnNuevo;
        private Button btnGrabar;
        private GroupBox gbTipoMantenimiento;
        private RadioButton rbCorrectivo;
        private RadioButton rbPreventivo;
        private DataGridView dgvMantenimiento;
        private TextBox txtTotalServicios;
        private Label lbTotalServicios;
        private TextBox txtTotalCorrectivo;
        private Label lbTotalTipoMant;
        private TextBox txtTotalPreventivo;
        private Label label10;
        private Label label9;
        private TextBox txtTotal;
        private TextBox txtSubtotal;
        private RichTextBox rtbServicios;
        private Button btnCalcular;
        private TextBox txtCliente;
        private Button btnCliente;
        private TextBox txtNombre;
        private GroupBox groupBox4;
        private Button btnServiciosAdicionales;
        private RichTextBox rtbRepuestos;
        private ComboBox cbVehiculo;
        private Label label3;
        private GroupBox gbServiciosAdicionales;
        private TextBox txtTotalServAd;
        private TextBox txtPrecioServicio;
        private Label label7;
        private Label label8;
        private CheckedListBox clbServiciosAdicionales;
    }
}